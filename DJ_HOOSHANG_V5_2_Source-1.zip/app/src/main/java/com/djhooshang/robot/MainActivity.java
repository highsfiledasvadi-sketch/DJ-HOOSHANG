package com.djhooshang.robot;
import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.hardware.*; import android.media.MediaPlayer; import android.net.Uri; import android.os.*; import android.provider.AlarmClock; import android.view.*; import android.widget.*; import org.json.JSONObject; import org.vosk.*; import org.vosk.android.*; import java.io.IOException; import java.io.File; import java.util.Locale;
public class MainActivity extends Activity implements SensorEventListener, RecognitionListener {
 FaceView face; TextView status; android.speech.tts.TextToSpeech tts; SensorManager sm; Sensor gyro; Model model; SpeechService speech; MediaPlayer player; boolean listening=false; long started=0,last=0; Handler h=new Handler(Looper.getMainLooper());
 public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
 LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(18,10,18,10);root.setBackgroundColor(0xff071323);
 TextView title=new TextView(this);title.setText("DJ HOOSHANG V5.2");title.setTextColor(-1);title.setTextSize(24);title.setGravity(17);root.addView(title,new LinearLayout.LayoutParams(-1,42));
 face=new FaceView(this);root.addView(face,new LinearLayout.LayoutParams(-1,0,1)); face.setOnTouchListener((v,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN||event.getAction()==MotionEvent.ACTION_MOVE){face.setMood("laugh");sayStatus("Hee hee! That tickles!");if(event.getAction()==MotionEvent.ACTION_DOWN)speak("Hee hee! That tickles!");h.removeCallbacksAndMessages(null);h.postDelayed(()->face.setMood("happy"),1200);return true;}return true;});
 status=new TextView(this);status.setTextColor(0xffb4e1ff);status.setGravity(17);status.setText("Hello! I'm ready.");root.addView(status,new LinearLayout.LayoutParams(-1,38));
 add(root,"Say hello",()->speak("Hello! I'm DJ Hooshang. It's nice to see you!"));add(root,"Talk / Chat (English)",this::talk);add(root,"Choose music",this::music);add(root,"Set wake-up alarm",this::alarm);add(root,"Connect Bluetooth device",()->startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)));add(root,"Mini game",this::game);add(root,"Study tutor (Grades 7-9)",this::study);setContentView(root);
 tts=new android.speech.tts.TextToSpeech(this,r->{if(r==0){tts.setLanguage(Locale.US);tts.setSpeechRate(.92f);}});
 sm=(SensorManager)getSystemService(SENSOR_SERVICE);if(sm!=null)gyro=sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);loadModel();}
 void add(LinearLayout l,String s,Runnable r){Button b=new Button(this);b.setText(s);l.addView(b,new LinearLayout.LayoutParams(-1,44));b.setOnClickListener(v->r.run());}
 void sayStatus(String s){status.setText(s);} void speak(String s){if(tts!=null)tts.speak(s,android.speech.tts.TextToSpeech.QUEUE_FLUSH,null);}
 void loadModel(){
   if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},8);return;}
   loadExternalModel();
 }
 void loadExternalModel(){
   File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"vosk-model-small-en-us-0.15");
   if(!new File(dir,"am").exists() || !new File(dir,"conf").exists()) {sayStatus("Put English Vosk model folder in Download.");return;}
   try { model=new Model(dir.getAbsolutePath()); sayStatus("Voice ready! Tap Talk and speak English."); }
   catch(Exception e){sayStatus("Could not load Vosk model: check folder contents.");}
 }
 void talk(){if(listening){if(speech!=null)speech.stop();speech=null;listening=false;sayStatus("Stopped.");return;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7);return;}startVosk();}
 void startVosk(){if(model==null){sayStatus("Vosk model missing. Add model files and rebuild.");return;}try{speech=new SpeechService(new Recognizer(model,16000f),16000f);speech.startListening(this);listening=true;sayStatus("Listening... say Hey DJ Hooshang.");}catch(IOException e){sayStatus("Microphone could not start.");}}
 public void onResult(String s){heard(s);} public void onFinalResult(String s){heard(s);listening=false;} public void onPartialResult(String s){} public void onError(Exception e){listening=false;sayStatus("Voice error. Tap Talk again.");} public void onTimeout(){listening=false;sayStatus("Timed out. Tap Talk again.");}
 void heard(String j){try{String s=new JSONObject(j).optString("text","").toLowerCase(Locale.US);if(s.contains("hey dj")||s.contains("hey hooshang")){sayStatus("Yes? I'm listening!");speak("Yes? I'm listening!");}else if(s.contains("hello")||s.contains("hi")){sayStatus("Hello!");speak("Hello! How are you?");}else if(s.contains("how are you")){sayStatus("I'm great!");speak("I'm feeling great, thank you!");}
 else if(s.contains("your name")||s.contains("who are you")){sayStatus("I'm DJ Hooshang!");speak("I'm DJ Hooshang, your little robot friend!");}
 else if(s.contains("thank you")||s.contains("thanks")){sayStatus("You're welcome!");speak("You're very welcome!");}
 else if(s.contains("good morning")){sayStatus("Good morning!");speak("Good morning! I hope you have a wonderful day!");}
 else if(s.contains("good night")){sayStatus("Good night!");speak("Good night! Sweet dreams!");face.setMood("sleepy");}
 else if(s.contains("play music")){sayStatus("Choose a music file.");music();}
 else if(s.contains("tell me a joke")){sayStatus("Robot joke time!");speak("Why did the robot go on vacation? It needed to recharge!");}
 else if(s.contains("study")||s.contains("teach me")){sayStatus("Let's study!");study();}
 else if(s.contains("bye")){sayStatus("See you soon!");speak("See you soon! I'll be here!");}
 else sayStatus(s.isEmpty()?"I didn't catch that.":"I heard: "+s+". Try hello, how are you, play music, or study.");}catch(Exception e){}}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7&&g.length>0&&g[0]==0)startVosk(); if(r==8&&g.length>0&&g[0]==0)loadExternalModel();}
 void music(){Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("audio/*");startActivityForResult(i.createChooser(i,"Choose music"),2);}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==2&&c==-1&&d!=null)try{if(player!=null)player.release();player=new MediaPlayer();player.setDataSource(this,d.getData());player.setOnPreparedListener(m->{m.start();sayStatus("Playing music.");});player.prepareAsync();}catch(Exception e){sayStatus("Could not play this file.");}}
 void alarm(){Intent i=new Intent(AlarmClock.ACTION_SET_ALARM);i.putExtra(AlarmClock.EXTRA_MESSAGE,"Wake up with DJ HOOSHANG");if(i.resolveActivity(getPackageManager())!=null)startActivity(i);else sayStatus("No clock app found.");}
 void game(){final int[] n={0};new AlertDialog.Builder(this).setTitle("Catch the star!").setMessage("Tap Catch to score a point.").setPositiveButton("Catch!",(d,w)->{n[0]++;new AlertDialog.Builder(this).setTitle("Score: "+n[0]).setPositiveButton("Again",(x,y)->game()).setNegativeButton("Close",null).show();}).setNegativeButton("Close",null).show();}

 void study(){
   final String[] grades={"Grade 7","Grade 8","Grade 9"};
   final String[] subjects={"Math","Science","Persian","English","Arabic"};
   final int[] g={0},s={0};
   LinearLayout box=new LinearLayout(this);box.setPadding(24,12,24,8);box.setOrientation(1);
   TextView intro=new TextView(this);intro.setText("DJ HOOSHANG Study Tutor\nChoose your grade and subject, then type a lesson topic.");intro.setTextSize(17);box.addView(intro);
   Spinner grade=new Spinner(this);grade.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,grades));box.addView(grade);
   Spinner subject=new Spinner(this);subject.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,subjects));box.addView(subject);
   EditText topic=new EditText(this);topic.setSingleLine(true);topic.setHint("Topic (example: integers)");box.addView(topic);
   grade.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){g[0]=p;}public void onNothingSelected(android.widget.AdapterView<?> a){}});
   subject.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){s[0]=p;}public void onNothingSelected(android.widget.AdapterView<?> a){}});
   new AlertDialog.Builder(this).setTitle("Study with DJ HOOSHANG").setView(box)
    .setPositiveButton("Teach me",(d,w)->showLesson(grades[g[0]],subjects[s[0]],topic.getText().toString().trim()))
    .setNeutralButton("Quick quiz",(d,w)->showStudyQuiz(subjects[s[0]],grades[g[0]]))
    .setNegativeButton("Close",null).show();
 }
 void showLesson(String grade,String subject,String topic){
   String t=topic.toLowerCase(Locale.US);String lesson;
   if(subject.equals("Math")&&(t.contains("integer")||t.contains("عدد صحیح")||t.contains("عددهای صحیح")||t.isEmpty())){
     lesson="Integers are positive whole numbers, negative whole numbers, and zero.\n\nExample: -3 is less than 2. On a number line, numbers farther right are greater.\n\nTip: When adding numbers with the same sign, add their distances from zero and keep the sign. With different signs, subtract the distances and keep the sign of the number farther from zero.\n\nTry: -4 + 7 = ?";
   }else if(subject.equals("Math")&&(t.contains("fraction")||t.contains("کسر"))){
     lesson="A fraction shows equal parts of a whole. The top number is the numerator; the bottom number is the denominator.\n\nExample: 1/2 means one of two equal parts. To add fractions with the same denominator, add the numerators and keep the denominator.\n\nTry: 2/5 + 1/5 = ?";
   }else if(subject.equals("Science")&&(t.contains("cell")||t.contains("سلول")||t.isEmpty())){
     lesson="A cell is the basic structural and functional unit of living things. Many organisms are made of many cells; some are single-celled.\n\nThe cell membrane controls what enters and leaves the cell. The cytoplasm is where many cell activities happen. Plant cells also have a cell wall and usually a large central vacuole.\n\nTry: Which part controls what enters and leaves the cell?";
   }else if(subject.equals("Persian")&&(t.contains("تشبیه")||t.contains("simile")||t.isEmpty())){
     lesson="تشبیه یعنی مانند کردن چیزی به چیز دیگر برای روشن‌تر و زیباتر شدن معنی.\n\nمثال: «صورتش مثل ماه روشن بود.» در این جمله، صورت به ماه تشبیه شده است. واژهٔ «مثل» نشانهٔ تشبیه است.\n\nتمرین: در جملهٔ «دلش مانند دریا آرام بود» چه چیزی به چه چیزی تشبیه شده است؟";
   }else if(subject.equals("English")&&(t.contains("present")||t.contains("حال ساده")||t.isEmpty())){
     lesson="The simple present describes habits and facts.\n\nExamples: I play football. She plays football.\n\nWith he, she, and it, the verb usually takes -s or -es.\n\nTry: He ___ (watch) TV every evening.";
   }else if(subject.equals("Arabic")&&(t.contains("اسم")||t.contains("فعل")||t.isEmpty())){
     lesson="در عربی، کلمه معمولاً سه دستهٔ اصلی دارد: اسم، فعل و حرف.\n\nاسم بر انسان، چیز یا مفهوم دلالت می‌کند؛ فعل انجام کار یا رخ دادن چیزی را در زمان نشان می‌دهد؛ حرف به‌تنهایی معنای کاملی ندارد و در کنار کلمات دیگر معنا می‌سازد.\n\nتمرین: در عبارت «کَتَبَ الطّالِبُ» کدام کلمه فعل است؟";
   }else{
     lesson="من برای این موضوع هنوز درس اختصاصیِ آماده در کتابخانهٔ آفلاین ندارم.\n\nموضوع را با نام دقیق‌تر وارد کن یا از موضوع‌های نمونه استفاده کن: اعداد صحیح، کسرها، سلول، تشبیه، زمان حال ساده، اسم و فعل.\n\nاین بخش فعلاً یک معلم آفلاینِ مقدماتی است؛ برای توضیح آزاد دربارهٔ همهٔ فصل‌های کتاب، بعداً باید محتوای درس‌ها یا اتصال به یک سرویس هوش مصنوعی اضافه شود.";
   }
   new AlertDialog.Builder(this).setTitle(grade+" • "+subject+(topic.isEmpty()?"":" • "+topic)).setMessage(lesson)
    .setPositiveButton("OK",null).show();
 }
 void showStudyQuiz(String subject,String grade){
   final String question,answer;
   if(subject.equals("Math")){question="What is -4 + 7?";answer="3";}
   else if(subject.equals("Science")){question="Which cell part controls what enters and leaves the cell?";answer="Cell membrane";}
   else if(subject.equals("Persian")){question="در «مثل ماه می‌درخشید» چه آرایه‌ای به‌کار رفته؟";answer="تشبیه";}
   else if(subject.equals("English")){question="Complete: She ___ (play) tennis every week.";answer="plays";}
   else {question="در «کَتَبَ الطّالِبُ» کدام واژه فعل است؟";answer="کَتَبَ";}
   EditText response=new EditText(this);response.setSingleLine(true);response.setHint("Your answer");
   new AlertDialog.Builder(this).setTitle(grade+" • "+subject+" quiz").setMessage(question).setView(response)
    .setPositiveButton("Check",(d,w)->{String got=response.getText().toString().trim();boolean ok=got.equalsIgnoreCase(answer)|| (subject.equals("Persian")&&got.contains(answer)) || (subject.equals("Arabic")&&got.contains(answer));new AlertDialog.Builder(this).setTitle(ok?"Correct!":"Let's learn").setMessage(ok?"Great work!":"Correct answer: "+answer).setPositiveButton("OK",null).show();})
    .setNegativeButton("Close",null).show();
 }
 public void onSensorChanged(SensorEvent e){if(e.sensor.getType()!=Sensor.TYPE_GYROSCOPE)return;float v=(float)Math.sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]);long now=System.currentTimeMillis();if(v>1.25f&&now-last>7000){if(started==0)started=now;if(now-started>450){started=0;last=now;face.setMood("dizzy");sayStatus("Whoa... a little spin!");speak("Whoa... a little spin!");h.postDelayed(()->{face.setMood("happy");sayStatus("I'm okay now.");},1100);}}else if(v<.55f)started=0;}
 public void onAccuracyChanged(Sensor s,int a){} protected void onResume(){super.onResume();if(sm!=null&&gyro!=null)sm.registerListener(this,gyro,SensorManager.SENSOR_DELAY_UI);} protected void onPause(){super.onPause();if(sm!=null)sm.unregisterListener(this);if(speech!=null){speech.stop();speech=null;listening=false;}} protected void onDestroy(){if(tts!=null)tts.shutdown();if(player!=null)player.release();if(model!=null)model.close();h.removeCallbacksAndMessages(null);super.onDestroy();}
}